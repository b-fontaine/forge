#!/usr/bin/env bash
# Forge — Foundations Structural Validator
# <!-- Audit: B.1 (b1-foundations) -->
#
# Validates that the deliverables of change `b1-foundations` are present
# and well-formed in the current FORGE_ROOT. Invoked from verify.sh on
# monorepo projects (i.e. when .forge/schemas/full-stack-monorepo/
# exists) and directly by b1-scaffolder once it lands.
#
# Contract:
#   - Exit 0 iff every FR-GL-00N check passes.
#   - Exit 1 if any check fails.
#   - Emits one line per FR-GL-00N check to stdout:
#       "PASS: FR-GL-00N — <short message>"
#       "FAIL: FR-GL-00N — <short message>"
#   - Idempotent: running twice on the same FORGE_ROOT produces the
#     same output and exit code (NFR-001).
#   - Must run < 2s on a standard dev machine (NFR-002).
#
# Parsing strategy (ADR-002): small python3 heredocs embedded in each
# check_* function, using yaml.safe_load only. No external deps beyond
# python3 stdlib, which is already present in the forge/linter image.
#
# Usage:
#   bash .forge/scripts/validate-foundations.sh
#   FORGE_ROOT=/path/to/fixture bash .forge/scripts/validate-foundations.sh

set -euo pipefail

FORGE_ROOT="${FORGE_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"

PASS=0
FAIL=0

# ─── PASS/FAIL helpers ──────────────────────────────────────────

pass_fr() {
  # pass_fr <FR-GL-XXX> <message>
  PASS=$((PASS + 1))
  printf 'PASS: %s — %s\n' "$1" "$2"
}

fail_fr() {
  # fail_fr <FR-GL-XXX> <message>
  FAIL=$((FAIL + 1))
  printf 'FAIL: %s — %s\n' "$1" "$2"
}

finalize() {
  # finalize — prints nothing else; caller sees PASS/FAIL lines.
  # Exits 0 if FAIL==0, else 1.
  if [ "$FAIL" -eq 0 ]; then
    return 0
  fi
  return 1
}

# ─── Section presence helper ────────────────────────────────────

# check_sections <fr_id> <path> <section1> [section2 ...]
# Fails fast with a message listing missing sections.
check_sections() {
  local fr="$1"; shift
  local path="$1"; shift
  local rel="${path#$FORGE_ROOT/}"
  if [ ! -f "$path" ]; then
    fail_fr "$fr" "standard file missing: $rel"
    return
  fi
  local missing=()
  local section
  for section in "$@"; do
    # -F fixed string, -x match entire line, -q quiet
    if ! grep -qFx "## $section" "$path"; then
      missing+=("$section")
    fi
  done
  if [ "${#missing[@]}" -gt 0 ]; then
    # Join array with ", " for readability.
    local joined
    joined=$(IFS=, ; printf '%s' "${missing[*]}")
    joined="${joined//,/, }"
    fail_fr "$fr" "missing sections in $rel: $joined"
    return
  fi
  pass_fr "$fr" "${rel} has all required sections"
}

# ─── Individual FR checks ───────────────────────────────────────

check_schema_full_stack_monorepo() {
  local path="$FORGE_ROOT/.forge/schemas/full-stack-monorepo/schema.yaml"
  if [ ! -f "$path" ]; then
    fail_fr "FR-GL-001" "schema file missing: .forge/schemas/full-stack-monorepo/schema.yaml"
    return
  fi
  local result
  result=$(python3 - "$path" <<'PY'
import sys, re, yaml
path = sys.argv[1]
try:
    with open(path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
except yaml.YAMLError as e:
    print(f"KO: YAML parse error: {e}"); sys.exit(0)

if not isinstance(data, dict):
    print("KO: schema root is not a mapping"); sys.exit(0)

if data.get('name') != 'full-stack-monorepo':
    print(f"KO: name mismatch (got {data.get('name')!r}, expected 'full-stack-monorepo')"); sys.exit(0)

version = data.get('version')
if not isinstance(version, str) or not re.match(r'^\d+\.\d+\.\d+(-[\w.-]+)?$', version):
    print(f"KO: version does not match SemVer (got {version!r})"); sys.exit(0)

layers = data.get('layers')
if not isinstance(layers, list) or not layers:
    print("KO: layers missing or empty"); sys.exit(0)

layer_ids = {l.get('id') for l in layers if isinstance(l, dict)}
required = {'backend', 'frontend', 'infra'}
if not required.issubset(layer_ids):
    missing = sorted(required - layer_ids)
    print(f"KO: layers must include at least backend, frontend, infra (missing: {missing})"); sys.exit(0)

for layer in layers:
    for key in ('id', 'path', 'fr_id_prefix', 'primary_agent'):
        if key not in layer:
            print(f"KO: layer {layer.get('id','?')!r} missing field {key!r}"); sys.exit(0)

stage = data.get('stage')
if stage not in ('draft', 'candidate', 'stable'):
    print(f"KO: stage must be one of draft/candidate/stable (got {stage!r})"); sys.exit(0)

if stage == 'stable':
    m = re.match(r'^(\d+)\.(\d+)\.(\d+)(-.*)?$', version)
    if not m or int(m.group(1)) < 1 or m.group(4):
        print(f"KO: stage=stable requires version >= 1.0.0 without prerelease (got {version!r})"); sys.exit(0)

phases = data.get('phases')
if not isinstance(phases, list) or not phases:
    print("KO: phases missing or empty"); sys.exit(0)

print(f"OK: schema {version} stage={stage} layers={sorted(layer_ids)}")
PY
)
  if [[ "$result" == OK:* ]]; then
    pass_fr "FR-GL-001" "${result#OK: }"
  else
    fail_fr "FR-GL-001" "${result#KO: }"
  fi
}

check_standard_monorepo_layout() {
  check_sections "FR-GL-002" \
    "$FORGE_ROOT/.forge/standards/global/monorepo-layout.md" \
    "Arborescence" \
    "Interdictions" \
    "CLAUDE.md imbriqués" \
    "Préfixes FR-ID"
}

check_standard_proto_contracts() {
  check_sections "FR-GL-003" \
    "$FORGE_ROOT/.forge/standards/global/proto-contracts.md" \
    "Arborescence shared/protos" \
    "Versioning (v1, v2, deprecation)" \
    "Gates CI (buf lint + buf breaking)" \
    "Génération des stubs (tonic-build, protoc_plugin)" \
    "Interdictions"
}

check_standard_docker_compose() {
  check_sections "FR-GL-004" \
    "$FORGE_ROOT/.forge/standards/infra/docker-compose.md" \
    "Service naming (fsm-*)" \
    "Réseau unique (fsm-dev)" \
    "Healthchecks obligatoires" \
    "Variables d'env (.env.example versionné)" \
    "Interdiction docker-compose.yml non suffixé"
}

check_git_workflow_scoped_commits() {
  local path="$FORGE_ROOT/.forge/standards/global/git-workflow.md"
  if [ ! -f "$path" ]; then
    fail_fr "FR-GL-005" "git-workflow.md missing"
    return
  fi
  if ! grep -qFx '## Scoped Conventional Commits (monorepo-only)' "$path"; then
    fail_fr "FR-GL-005" "section 'Scoped Conventional Commits (monorepo-only)' missing"
    return
  fi
  # Closed scope list must appear on one line containing all 7 tokens in order.
  if ! grep -qE 'backend.*frontend.*infra.*protos.*forge.*docs.*ci' "$path"; then
    fail_fr "FR-GL-005" "closed scope list {backend, frontend, infra, protos, forge, docs, ci} not found"
    return
  fi
  pass_fr "FR-GL-005" "git-workflow scoped commits section present"
}

check_index_new_entries() {
  local path="$FORGE_ROOT/.forge/standards/index.yml"
  if [ ! -f "$path" ]; then
    fail_fr "FR-GL-007" "index.yml missing"
    return
  fi
  local result
  result=$(python3 - "$path" <<'PY'
import sys, yaml
path = sys.argv[1]
try:
    with open(path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
except yaml.YAMLError as e:
    print(f"KO: YAML parse error: {e}"); sys.exit(0)

standards = data.get('standards') if isinstance(data, dict) else None
if not isinstance(standards, list):
    print("KO: standards root missing or not a list"); sys.exit(0)

expected = {
    'global/monorepo-layout': {'scope': 'monorepo', 'priority': 'high'},
    'global/proto-contracts': {'scope': 'protos', 'priority': 'high'},
    'infra/docker-compose': {'scope': 'infra', 'priority': 'medium'},
}

found = {}
for entry in standards:
    if not isinstance(entry, dict): continue
    eid = entry.get('id')
    if eid in expected:
        found[eid] = entry

missing = sorted(set(expected) - set(found))
if missing:
    print(f"KO: missing index entries: {missing}"); sys.exit(0)

for eid, want in expected.items():
    got = found[eid]
    if got.get('scope') != want['scope']:
        print(f"KO: {eid} scope mismatch (got {got.get('scope')!r}, expected {want['scope']!r})"); sys.exit(0)
    if got.get('priority') != want['priority']:
        print(f"KO: {eid} priority mismatch (got {got.get('priority')!r}, expected {want['priority']!r})"); sys.exit(0)
    if not isinstance(got.get('triggers'), list) or not got['triggers']:
        print(f"KO: {eid} triggers missing or empty"); sys.exit(0)

print("OK: 3 new monorepo standards present and well-formed")
PY
)
  if [[ "$result" == OK:* ]]; then
    pass_fr "FR-GL-007" "${result#OK: }"
  else
    fail_fr "FR-GL-007" "${result#KO: }"
  fi
}

check_standard_multi_layer_workflow() {
  check_sections "FR-GL-018" \
    "$FORGE_ROOT/.forge/standards/global/multi-layer-workflow.md" \
    "Routing Policy" \
    ".forge.yaml Multi-Layer Schema" \
    "Per-Layer Design Convention" \
    "Per-Layer Tasks Convention" \
    "Cross-Layer Contract Alignment" \
    "Interdictions"
}

check_multi_layer_change_metadata() {
  # Activates only on monorepo projects. On non-monorepo projects,
  # `.forge/schemas/full-stack-monorepo/schema.yaml` is absent and this
  # check skips silently via an N/A PASS (keeps FAIL count at 0).
  if [ ! -f "$FORGE_ROOT/.forge/schemas/full-stack-monorepo/schema.yaml" ]; then
    pass_fr "FR-GL-017" "skipped (not a monorepo project)"
    return
  fi
  local result
  result=$(python3 - "$FORGE_ROOT" <<'PY'
import os, sys, glob, yaml
forge_root = sys.argv[1]
schema_path = os.path.join(forge_root, '.forge/schemas/full-stack-monorepo/schema.yaml')
try:
    with open(schema_path, 'r', encoding='utf-8') as f:
        schema = yaml.safe_load(f)
except yaml.YAMLError as e:
    print(f"KO: schema parse error: {e}"); sys.exit(0)
known_ids = {l.get('id') for l in schema.get('layers', []) if isinstance(l, dict)}

changes_dir = os.path.join(forge_root, '.forge/changes')
if not os.path.isdir(changes_dir):
    print("OK: no changes directory (acceptable)"); sys.exit(0)

failures = []
inspected = 0
for cdir in sorted(glob.glob(os.path.join(changes_dir, '*/'))):
    name = os.path.basename(cdir.rstrip('/'))
    yml = os.path.join(cdir, '.forge.yaml')
    if not os.path.isfile(yml):
        continue
    try:
        with open(yml, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError as e:
        failures.append(f"{name}: parse error: {e}"); continue
    layers = data.get('layers')
    if layers is None or (isinstance(layers, list) and len(layers) <= 1):
        # Single-layer or no layers — acceptable, no per-layer files expected.
        inspected += 1
        continue
    if not isinstance(layers, list):
        failures.append(f"{name}: layers must be a list"); continue
    # Layer entries may be plain id strings OR {id, path, ...} mappings
    # (the live .forge.yaml convention — every multi-layer change uses the
    # mapping shape). Normalise to ids before the set-membership test: a
    # dict in `l not in known_ids` raises TypeError: unhashable type, which
    # silently killed FR-GL-017 on the live tree (set -e aborted the script
    # mid-run; verify.sh masked it by grepping PASS/FAIL lines, not the
    # exit code).
    layer_ids = [l.get('id') if isinstance(l, dict) else l for l in layers]
    # Validate layer ids against schema enum.
    unknown = [i for i in layer_ids if i not in known_ids]
    if unknown:
        failures.append(f"{name}: unknown layer id {unknown!r} (known: {sorted(known_ids)})")
        continue
    # When >= 2 layers, designs_per_layer and tasks_per_layer required.
    designs = data.get('designs_per_layer')
    tasks   = data.get('tasks_per_layer')
    if not isinstance(designs, dict) or not designs:
        failures.append(f"{name}: designs_per_layer missing or empty for multi-layer change")
        continue
    if not isinstance(tasks, dict) or not tasks:
        failures.append(f"{name}: tasks_per_layer missing or empty for multi-layer change")
        continue
    # Each referenced file must exist.
    for layer, rel in designs.items():
        if layer not in layer_ids:
            failures.append(f"{name}: designs_per_layer has unknown layer '{layer}'"); break
        if not os.path.isfile(os.path.join(cdir, rel)):
            failures.append(f"{name}: designs_per_layer[{layer}] -> {rel} does not exist"); break
    else:
        for layer, rel in tasks.items():
            if layer not in layer_ids:
                failures.append(f"{name}: tasks_per_layer has unknown layer '{layer}'"); break
            if not os.path.isfile(os.path.join(cdir, rel)):
                failures.append(f"{name}: tasks_per_layer[{layer}] -> {rel} does not exist"); break
        else:
            inspected += 1
            continue
    continue

if failures:
    # First failure drives the message (keeps the FAIL line compact).
    print(f"KO: {failures[0]}"); sys.exit(0)
print(f"OK: {inspected} change(s) inspected, metadata consistent")
PY
)
  if [[ "$result" == OK:* ]]; then
    pass_fr "FR-GL-017" "${result#OK: }"
  else
    fail_fr "FR-GL-017" "${result#KO: }"
  fi
}

check_versioning_monorepo_section() {
  local path="$FORGE_ROOT/docs/VERSIONING.md"
  if [ ! -f "$path" ]; then
    fail_fr "FR-GL-006" "docs/VERSIONING.md missing"
    return
  fi
  if ! grep -qFx '## Monorepo Versioning Models' "$path"; then
    fail_fr "FR-GL-006" "section 'Monorepo Versioning Models' missing"
    return
  fi
  if ! grep -qFx '### Release-train' "$path"; then
    fail_fr "FR-GL-006" "subsection '### Release-train' missing"
    return
  fi
  if ! grep -qFx '### Per-package via release-please' "$path"; then
    fail_fr "FR-GL-006" "subsection '### Per-package via release-please' missing"
    return
  fi
  pass_fr "FR-GL-006" "versioning monorepo models present"
}

# ─── FR-GL-001 (versioned schema siblings) — B.8.3.b ────────────
#
# Discover versioned schema files `<archetype>/<X.Y.Z>.yaml` alongside the
# canonical `schema.yaml` and validate each with the same rule-set applied to
# schema.yaml, PLUS two new invariants:
#   - filename <-> version : `X.Y.Z.yaml` MUST declare `version: "X.Y.Z"`.
#   - stage: candidate ⇒ scaffoldable: false (stable/draft are exempt — the
#     frozen 1.0.0 schema.yaml is stable and carries no scaffoldable field).
# Generic across all archetype dirs; a dir with no versioned sibling is a no-op
# (the glob stays literal and the existence guard skips it). The emitted tag
# `FR-GL-001-versioned:<arch>/<file>` extends the FR-GL-001 schema concern
# (ADR-B83B-003) rather than leaking a change-scoped id into stdout.
check_versioned_schema_siblings() {
  local schemas_dir="$FORGE_ROOT/.forge/schemas"
  [ -d "$schemas_dir" ] || return 0
  # No-op when a dir has no versioned sibling: the glob stays a literal pattern
  # and `[ -e ]` skips it. This relies on default (no `nullglob`/`failglob`)
  # shell options, which this script does not set.
  local arch_dir archetype vf basename_file result fr_tag
  for arch_dir in "$schemas_dir"/*/; do
    [ -d "$arch_dir" ] || continue
    archetype=$(basename "$arch_dir")
    for vf in "$arch_dir"[0-9]*.[0-9]*.[0-9]*.yaml; do
      [ -e "$vf" ] || continue
      basename_file=$(basename "$vf")
      result=$(python3 - "$vf" "$archetype" "$basename_file" <<'PY'
import sys, re, yaml
path, archetype, fname = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    with open(path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
except Exception as e:
    # Catch-all (not just YAMLError): an unreadable/permission error must
    # surface as a clean KO line, never an uncaught traceback that aborts the
    # script under set -e (the failure mode FR-GL-017 hit before 6175a61).
    print(f"KO: load error: {e}"); sys.exit(0)
if not isinstance(data, dict):
    print("KO: schema root is not a mapping"); sys.exit(0)
if data.get('name') != archetype:
    print(f"KO: name mismatch (got {data.get('name')!r}, expected {archetype!r} from dir)"); sys.exit(0)
version = data.get('version')
if not isinstance(version, str) or not re.match(r'^\d+\.\d+\.\d+(-[\w.-]+)?$', version):
    print(f"KO: version does not match SemVer (got {version!r})"); sys.exit(0)
# NEW invariant 1: filename <-> version.
expected = fname[:-5] if fname.endswith('.yaml') else fname
if version != expected:
    print(f"KO: filename/version mismatch (file {fname} implies {expected!r}, schema declares {version!r})"); sys.exit(0)
layers = data.get('layers')
if not isinstance(layers, list) or not layers:
    print("KO: layers missing or empty"); sys.exit(0)
layer_ids = {l.get('id') for l in layers if isinstance(l, dict)}
required = {'backend', 'frontend', 'infra'}
if not required.issubset(layer_ids):
    print(f"KO: layers must include backend, frontend, infra (missing: {sorted(required - layer_ids)})"); sys.exit(0)
for layer in layers:
    if not isinstance(layer, dict):
        print("KO: a layer entry is not a mapping"); sys.exit(0)
    for key in ('id', 'path', 'fr_id_prefix', 'primary_agent'):
        if key not in layer:
            print(f"KO: layer {layer.get('id','?')!r} missing field {key!r}"); sys.exit(0)
stage = data.get('stage')
if stage not in ('draft', 'candidate', 'stable'):
    print(f"KO: stage must be one of draft/candidate/stable (got {stage!r})"); sys.exit(0)
if stage == 'stable':
    m = re.match(r'^(\d+)\.(\d+)\.(\d+)(-.*)?$', version)
    if not m or int(m.group(1)) < 1 or m.group(4):
        print(f"KO: stage=stable requires version >= 1.0.0 without prerelease (got {version!r})"); sys.exit(0)
# NEW invariant 2: candidate ⇒ scaffoldable: false (stable/draft exempt).
if stage == 'candidate' and data.get('scaffoldable') is not False:
    print(f"KO: stage=candidate requires scaffoldable: false (got {data.get('scaffoldable')!r})"); sys.exit(0)
phases = data.get('phases')
if not isinstance(phases, list) or not phases:
    print("KO: phases missing or empty"); sys.exit(0)
print(f"OK: versioned schema {version} stage={stage} layers={sorted(layer_ids)}")
PY
)
      fr_tag="FR-GL-001-versioned:${archetype}/${basename_file}"
      if [[ "$result" == OK:* ]]; then
        pass_fr "$fr_tag" "${result#OK: }"
      else
        fail_fr "$fr_tag" "${archetype}/${basename_file}: ${result#KO: }"
      fi
    done
  done
}

# ─── Main dispatcher ────────────────────────────────────────────

main() {
  # The Phase 1 RED stub for FR-GL-001 was replaced by check_schema_full_stack_monorepo
  # during Phase 2.1. Phase 3.1 task "remove the stub" is therefore retroactively done.
  check_schema_full_stack_monorepo
  check_standard_monorepo_layout
  check_standard_proto_contracts
  check_standard_docker_compose
  check_git_workflow_scoped_commits
  check_versioning_monorepo_section
  check_index_new_entries
  # b1-workflow additions (FR-GL-017, FR-GL-018).
  check_standard_multi_layer_workflow
  check_multi_layer_change_metadata
  # B.8.3.b — versioned schema siblings (<archetype>/<X.Y.Z>.yaml).
  check_versioned_schema_siblings

  finalize
}

main "$@"
